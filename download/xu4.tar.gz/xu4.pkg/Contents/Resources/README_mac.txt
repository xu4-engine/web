XU4_mac
========

This is a quick and dirty document describing the basic steps I used to get XU4 up and running on Mac OS X.  This document assumes you are comfortable using the Unix foundation of OSX (for example, opening a Terminal window or compiling programs).


This installer will place two version of XU4 on your computer.  The program named xu4 is a OS X app bundle.  The u4 file is the command line version for you terminal junkies.


A)  If you have the DOS Ultima 4 games files installed in /usr/lib or /usr/local/lib:
	Just install the files where ever you want them to live (I put mine in ~/Games/XU4/).  Double-click the xu4 icon and the game should run.
	If you want to use one of the start up options you'll need to use the included command line version instead.  Change to the directory where you installed these files and type ./u4 to run the game.


-OR-

B)  If you have the DOS Ultima 4 games files installed elsewhere (such as somewhere below your $HOME directory):
	Install the files to the _parent_ directory (folder) where you have your Ultima 4 game files.  Double-click the xu4 icon and the game should run.
	If you want to use one of the start up options (or you just like the terminal ;-)) you'll need to use the included command line version instead.  Change to the directory where you installed the files and type ./u4 to run the game.

	As an example, let's say you want to have XU4 in ~/Games/XU4.  xu4 (and/or u4) would go in the ~/Games/XU4 directory and the DOS Ultima 4 files would go in the ~/Games/XU4/ultima4 directory.  The directory tree would look like this:
		~				<-- your $HOME directory
		|
		\- Games
			|
			\- XU4			<-- the directory where to put xu4 (or u4)
				|
				\- ultima4	<-- the directory where the DOS Ultima 4 files are (the MIDI files can be here too)



COMPILING
=========

My system is running Mac OS X 10.2.4 with all the Software Updates applied as of March 7, 2003.  I don't have access to prior versions of OS X so be warned that you might have some problems.

In order to compile and/or run XU4 you need to have:
	1)  the full set of developer tools installed,
	2)  the SDL library installed,
	3)  the SDL_mixer library installed,
	4)  a directory named ultima4 (with the Ultima 4 game files) in the same directory where you have the XU4 program installed.

NOTE:  I also put the MIDI music files in the ultima4 directory to make it easier to move the game around.  If you want to keep the MIDI files separate they'll need to be in a directory named mid that is in the _parent_ directory of where you put the XU4 program.

NOTE:  Your save game files will be created in the same directory as where the XU4 program is.  If you want to continue with an existing Ultima 4 game, copy the *.sav files to the XU4 folder.



SDL
---
In order to have SDL support for make/configure you need to either install the SDL source and compile it or grab the latest CVS version and install that.  I generally grab the CVS version, but that version isn't always the most stable thing.  Use whichever version you are most comfortable with.


To compile the stable source code version download SDL-1.2.5.tar.gz from <http://www.libsdl.org/download-1.2.php>.  open a terminal window and change to your development directory (mine is ~/Projects).  From there type in the following commands:
	tar xzvf SDL-1.2.5.tar.gz
	cd SDL-1.2.5
	./autogen.sh
	./configure
	make
	sudo make install 

That's it.  You should have a working copy of SDL installed now.


 -OR-

To compile from the CVS version, open a terminal window and change to your development directory (mine is ~/Projects).  From there type in the follow commands:
	cvs -d :pserver:guest@libsdl.org:/home/sdlweb/libsdl.org/cvs login
	# Hit <return> when prompted for a password

	cvs -z3 -d :pserver:guest@libsdl.org:/home/sdlweb/libsdl.org/cvs checkout SDL12
	cd SDL12
	./autogen.sh
	./configure
	make
	sudo make install 


That's it.  You should have a working copy of SDL installed now.  If you need more information on the CVS version of SDL please see <http://www.libsdl.org/cvs.php>.



SDL_mixer
---------
Unfortunately, the current stable versions of SDL_mixer at <http://www.libsdl.org/projects/SDL_mixer/> are broken with respect to playing MIDI files on Mac OS X.  You'll have to get the CVS version of SDL_mixer if you want XU4 to play MIDI music.  (It will hang with any older version of SDL_mixer.  There's some sort of deadlock with Quicktime in the older versions of SDL_mixer.)

Open a terminal window and change to your development directory (mine is ~/Projects).  From there type in the follow commands:
	cvs -d :pserver:guest@libsdl.org:/home/sdlweb/libsdl.org/cvs login
	# Hit <return> when prompted for a password

	cvs -z3 -d :pserver:guest@libsdl.org:/home/sdlweb/libsdl.org/cvs checkout SDL_mixer
	cd SDL12
	./autogen.sh
	./configure
	make
	sudo make install 




XU4
---
Open a terminal window and change to the u4/src directory below your development directory and type make (mine is ~/Projects/xu4/u4/src).  XU4 should compile cleanly at this point.  Type ./u4 to run the game.



To Do
=====
In the future I would like to create an app bundle that has all the necessary files included (MIDI and the actual Ultima 4 game files).  Some of this will need to wait until a new stable binary version of SDL_mixer is available.



Administrivia
=============

Author: Edward Franks
Email:  fortrandragon@hotmail.com

Created: March 07, 2003
Updated: March 08, 2003
