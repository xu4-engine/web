INSTALL README
==============

*****
IMPORTANT, PLEASE READ THIS NOTE:  Please select a destination *folder* after selecting a destination disk.  You really don't want to be installing XU4 in your root (/) folder!
*****


This installer will place two version of XU4 on your computer.  The program named xu4 is a OS X app bundle.  The u4 file is the command line version for you terminal junkies.

A)  If you have the DOS Ultima 4 games files installed in /usr/lib or /usr/local/lib:
	Just install the files where ever you want them to live (I put mine in ~/Games/XU4/).  Double-click the xu4 icon and the game should run.
	If you want to use one of the start up options you'll need to use the included command line version instead.  Change to the directory where you installed these files and type ./u4 to run the game.


-OR-

B)  If you have the DOS Ultima 4 games files installed elsewhere (such as somewhere below your $HOME directory):
	Install the files to the _parent_ directory (folder) where you have your Ultima 4 game files.  Double-click the xu4 icon and the game should run.
	If you want to use one of the start up options (or you just like the terminal ;-)) you'll need to use the included command line version instead.  Change to the directory where you installed the files and type ./u4 to run the game.

	As an example, let's say you want to have XU4 in ~/Games/XU4.  xu4 (and/or u4) would go in the ~/Games/XU4 directory and the DOS Ultima 4 files would go in the ~/Games/XU4/ultima4 directory.  The directory tree would look like this:
		~				<-- your $HOME directory
		|
		\- Games
			|
			\- XU4			<-- the directory where to put xu4 (or u4)
				|
				\- ultima4	<-- the directory where the DOS Ultima 4 files are (the MIDI files can be here too)




Please see the README_mac.txt in the directory where you installed the files for more information about needed libraries and/or compiling the source code on OS X.



Administrivia
=============

Author: Edward Franks
Email:  fortrandragon@hotmail.com

Created: March 08, 2003
